// EDIT HOTEL POP-UP

// Get the modal
var modal = document.getElementById('editHotel-modal');

// Get the button that opens the modal
var btn = document.getElementById("editHotel-btn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks on the button, open the modal 
btn.onclick = function() {
    modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}

// Closes modal.
function closeWindow() {
	modal.style.display = "none";
}

// Preview the image to be uploaded.
function preview_image(event) 
{
 var reader = new FileReader();
 reader.onload = function()
 {
  var output = document.getElementById('output_image');
  output.src = reader.result;
 }
 reader.readAsDataURL(event.target.files[0]);
}

/*
// EDIT Personal Information POP-UP

// Get the modal
var modal_PI = document.getElementById('editPI-modal');

// Get the button that opens the modal
var btn_PI = document.getElementById("editPI-btn");

// Get the <span> element that closes the modal
var span_PI = document.getElementsByClassName("close")[0];

// When the user clicks on the button, open the modal 
btn_PI.onclick = function() {
    modal_PI.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span_PI.onclick = function() {
    modal_PI.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal_PI.style.display = "none";
    }
}

// Closes modal.
function closeWindow() {
	modal.style.display = "none";
}
*/